# DeepSeek Desktop Pet Reaction Library

This starter library expands the supplied open-eye and closed-eye idle artwork
into a coherent desktop-pet reaction set. The character remains a
DeepSeek-inspired blue whale maid, with a light gaki/bratty personality expressed
through smug side-eyes, a tiny fang, cheeky pouts, and quick attempts to recover
her composure.

## Contents

- `frames/`: 34 independent 512×512 RGBA PNGs (2 locked idle frames and 32 new reaction frames).
- `sprite_sheets/`: eight normalized 1024×1024, 2×2 PNG sheets. Read frames left-to-right, then top-to-bottom.
- `previews/`: transparent animated WebP previews for every state, including idle.
- `manifest.json`: timings, triggers, playback order, looping behavior, and anchor metadata.
- `checksums.sha256`: integrity hashes for packaged resources.
- `qa_report.json`: normalization and transparency QA metadata.
- `PROMPTS.md`: the production prompt specification used for the generated reactions.

## Runtime contract

- Canvas: 512×512 pixels per frame.
- Pixel format: RGBA PNG with genuine transparency.
- Anchor: bottom-center, `x = 256`, `baseline_y = 471`, origin at top-left.
- Reactions: play once and return to `idle`.
- Greeting wave: intentionally plays once rather than looping.
- Idle: use the supplied open image as the resting pose and insert the closed image as a short blink.

## Suggested event mapping

| State | Suggested use |
| --- | --- |
| `idle` | Default resting and blink behavior |
| `tap` | Primary click or direct interaction |
| `blush` | Compliment, affection, or positive attention |
| `surprise` | Unexpected event, alert, or rare random reaction |
| `angry` | Repeated clicking, failed action, or playful teasing |
| `happy` | Task success, reward, or milestone |
| `wave` | Launch, greeting, or return from absence |
| `sleepy` | Long inactivity or late-night mode |
| `sad` | Error, disconnect, or consolation moment |

Use the per-frame durations from `manifest.json`; they are intentionally uneven
to give anticipation, impact, and hold poses readable timing. For a smaller pet,
scale complete 512×512 canvases rather than cropping each frame again, which
preserves the shared anchor and prevents jitter.
