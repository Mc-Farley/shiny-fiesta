# Reaction Generation Prompt Set

## Shared production specification

Use both supplied idle PNGs as locked references for the same character. Preserve
the long navy-to-azure wavy hair, curled ahoge, maid headband, blue bow and white
feather-like ornament on screen-right, blue eyes, pale skin, tiny fang, navy maid
dress with gold embroidery, white ruffles, whale-emblem apron, white stockings,
and navy shoes. Match the reference chibi anime linework, palette, rendering,
proportions, highlights, camera, scale, and bottom-center anchor.

The character is a cute personification of the DeepSeek AI model. Give her a
light gaki/bratty character—clever, smug, mischievous, and playfully defiant,
never mean or sexualized. Generate four sequential full-body frames in a 2×2
sheet, read left-to-right then top-to-bottom. Keep the background genuinely
transparent with no panel, label, prop, floor, shadow, or redesign. Only pose,
expression, and subtle hair/clothing follow-through may change.

## State directions

- **Tap:** smug idle → closed-eye squash → startled upward pop with hands near chest → “you actually clicked me?” side-eye recovery.
- **Blush:** composed smirk → blush blooms while looking aside → deep blush with defensive hmph → half-lidded flustered peek-back.
- **Surprise:** confident idle → sudden wide-eyed startle → hands-to-cheeks peak → embarrassed arms-folding pout.
- **Angry:** side-eye → puffed cheeks and clenched fists → tiny contained stomp → arms-crossed hmph.
- **Happy:** pleased idle → proud anticipation → closed-eye joyful hop → self-satisfied landing.
- **Wave:** smug idle → screen-left hand rises → one cheeky wave → hand lowers with a teasing wink; play once.
- **Sleepy:** “not tired” half-lidded idle → hand rises → covered yawn → stubborn drowsy denial.
- **Sad:** confidence falters → small pout and hands close → restrained watery-eyed sulk → vulnerable bratty peek-back.
